package com.fatesg.ads4.projetoMirror.services;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

class CargoServiceTest {

	@Autowired
	CargoService service = new CargoService();
	
	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void test() {
		
		
		
	}

}
