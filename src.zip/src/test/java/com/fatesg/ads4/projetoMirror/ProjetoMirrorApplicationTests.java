package com.fatesg.ads4.projetoMirror;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoMirrorApplicationTests {

	@Test
	void contextLoads() {
	}

}
